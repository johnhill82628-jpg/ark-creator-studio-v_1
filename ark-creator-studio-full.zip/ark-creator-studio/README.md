# ARK CREATOR STUDIO

Cloudflare Worker + D1 + Groq API app with server-side authentication, user-isolated script history, free/pro plans, developer controls, and admin-managed plan activation.

## 1. Create D1 database

```bash
npx wrangler d1 create ark-creator-studio-db
```
Copy the returned database ID into `wrangler.toml` in place of `REPLACE_WITH_YOUR_D1_DATABASE_ID`.

## 2. Apply schema

```bash
npx wrangler d1 migrations apply ark-creator-studio-db --remote
```

## 3. Configure secrets

```bash
npx wrangler secret put GROQ_API_KEY
npx wrangler secret put ADMIN_SETUP_KEY
```
Use a new Groq API key if an old key was ever shared in a chat or source file. `ADMIN_SETUP_KEY` should be a long, random secret. Never put either secret in `public/index.html` or commit them to GitHub.

## 4. Deploy

```bash
npx wrangler deploy
```

## 5. Create first admin

Open the deployed app. Expand **One-time Admin Setup**, enter the `ADMIN_SETUP_KEY`, an admin email, and a password of at least 10 characters. This endpoint only works while no admin exists. Once created, the setup route rejects further attempts. Log in with that admin account.

## Features and limits

- Registration creates a Free account.
- Free: 5 generations/day, up to 60 seconds, no Developer Mode.
- Pro: 100 generations/day, up to 6 minutes, Developer Mode.
- Admin can switch users between Free and Pro in Admin Panel.
- Script history is filtered by authenticated user ID on every query.
- Passwords are salted PBKDF2-SHA-256 hashes; sessions use random tokens stored only as SHA-256 hashes in D1 and are delivered in Secure, HttpOnly, SameSite=Lax cookies.

## Important deployment notes

- Serve the app and API from the same Worker origin so the HttpOnly session cookie is same-origin.
- D1 migration must be applied to the same database bound as `DB`.
- The API enforces plan checks server-side; hiding controls in HTML is not the security boundary.
- This starter does not implement email verification, password reset, paid checkout, or multi-factor authentication. Add these before operating a public paid service at scale.
