import { generateScript } from "./groq.js";
import {
  randomId,
  hashPassword,
  verifyPassword,
  isStrongEnoughPassword,
  createSession,
  getCurrentUser,
  deleteCurrentSession,
  sessionCookie,
  clearSessionCookie
} from "./auth.js";

const FREE_DAILY_LIMIT = 5;
const PRO_DAILY_LIMIT = 100;
const JSON_HEADERS = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" };

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), { status, headers: { ...JSON_HEADERS, ...extraHeaders } });
}

async function readJson(request) {
  try { return await request.json(); } catch { return null; }
}

function normalizeEmail(value) {
  return String(value || "").trim().toLowerCase();
}

function validEmail(email) {
  return email.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function safeUser(user) {
  return {
    id: user.id,
    email: user.email,
    role: user.role,
    plan: user.plan,
    createdAt: user.created_at || user.createdAt || null
  };
}

function sameOriginOrNoOrigin(request, url) {
  const origin = request.headers.get("Origin");
  return !origin || origin === url.origin;
}

async function requireUser(request, env) {
  if (!env.DB) throw new Error("D1 binding DB မချိတ်ထားပါ။");
  return getCurrentUser(request, env.DB);
}

function requireAdmin(user) {
  return user && user.role === "admin";
}

async function api(request, env, url) {
  const path = url.pathname;
  const method = request.method.toUpperCase();

  if (!env.DB) return json({ ok: false, error: "D1 binding DB မချိတ်ထားပါ။" }, 500);

  if (method !== "GET" && method !== "HEAD" && !sameOriginOrNoOrigin(request, url)) {
    return json({ ok: false, error: "Cross-origin request ကို ခွင့်မပြုပါ။" }, 403);
  }

  if (path === "/api/health" && method === "GET") {
    return json({ ok: true, app: "ARK CREATOR STUDIO", worker: true, database: true, keyConfigured: Boolean(env.GROQ_API_KEY) });
  }

  if (path === "/api/auth/register" && method === "POST") {
    const body = await readJson(request);
    if (!body) return json({ ok: false, error: "Request JSON မမှန်ပါ။" }, 400);
    const email = normalizeEmail(body.email);
    const password = String(body.password || "");
    if (!validEmail(email)) return json({ ok: false, error: "မှန်ကန်တဲ့ Email ထည့်ပါ။" }, 400);
    if (!isStrongEnoughPassword(password)) return json({ ok: false, error: "Password ကို အနည်းဆုံး ၁၀ လုံး၊ အများဆုံး ၁၂၈ လုံး ထည့်ပါ။" }, 400);

    const existing = await env.DB.prepare("SELECT id FROM users WHERE email = ?").bind(email).first();
    if (existing) return json({ ok: false, error: "ဒီ Email ကို အသုံးပြုပြီးသားပါ။ Login ဝင်ပါ။" }, 409);

    const id = randomId();
    const passwordHash = await hashPassword(password);
    try {
      await env.DB.prepare("INSERT INTO users (id, email, password_hash, role, plan) VALUES (?, ?, ?, 'user', 'free')")
        .bind(id, email, passwordHash).run();
    } catch (error) {
      if (String(error).toLowerCase().includes("unique")) return json({ ok: false, error: "ဒီ Email ကို အသုံးပြုပြီးသားပါ။" }, 409);
      throw error;
    }
    const session = await createSession(env.DB, id);
    const user = await env.DB.prepare("SELECT id, email, role, plan, created_at FROM users WHERE id = ?").bind(id).first();
    return json({ ok: true, user: safeUser(user) }, 201, { "Set-Cookie": sessionCookie(session.token) });
  }

  if (path === "/api/auth/login" && method === "POST") {
    const body = await readJson(request);
    if (!body) return json({ ok: false, error: "Request JSON မမှန်ပါ။" }, 400);
    const email = normalizeEmail(body.email);
    const password = String(body.password || "");
    if (!validEmail(email) || !password || password.length > 128) {
      return json({ ok: false, error: "Email သို့မဟုတ် Password မမှန်ပါ။" }, 400);
    }

    const now = Math.floor(Date.now() / 1000);
    let attempt = await env.DB.prepare("SELECT attempts, window_started FROM login_attempts WHERE email = ?").bind(email).first();
    if (attempt && now - attempt.window_started < 900 && attempt.attempts >= 8) {
      return json({ ok: false, error: "Login ကြိုးစားမှုများလွန်းပါတယ်။ ၁၅ မိနစ်ကြာပြီးမှ ထပ်စမ်းပါ။" }, 429);
    }
    if (!attempt || now - attempt.window_started >= 900) {
      await env.DB.prepare(`INSERT INTO login_attempts (email, attempts, window_started) VALUES (?, 0, ?)
        ON CONFLICT(email) DO UPDATE SET attempts = 0, window_started = excluded.window_started`).bind(email, now).run();
    }

    const user = await env.DB.prepare("SELECT id, email, password_hash, role, plan, created_at FROM users WHERE email = ?").bind(email).first();
    const passwordOk = user ? await verifyPassword(password, user.password_hash) : false;
    if (!user || !passwordOk) {
      await env.DB.prepare(`INSERT INTO login_attempts (email, attempts, window_started) VALUES (?, 1, ?)
        ON CONFLICT(email) DO UPDATE SET attempts = CASE WHEN ? - window_started >= 900 THEN 1 ELSE attempts + 1 END,
        window_started = CASE WHEN ? - window_started >= 900 THEN ? ELSE window_started END`)
        .bind(email, now, now, now, now).run();
      return json({ ok: false, error: "Email သို့မဟုတ် Password မမှန်ပါ။" }, 401);
    }
    await env.DB.prepare("DELETE FROM login_attempts WHERE email = ?").bind(email).run();
    const session = await createSession(env.DB, user.id);
    return json({ ok: true, user: safeUser(user) }, 200, { "Set-Cookie": sessionCookie(session.token) });
  }

  if (path === "/api/auth/logout" && method === "POST") {
    await deleteCurrentSession(request, env.DB);
    return json({ ok: true }, 200, { "Set-Cookie": clearSessionCookie() });
  }

  if (path === "/api/auth/me" && method === "GET") {
    const user = await requireUser(request, env);
    if (!user) return json({ ok: false, authenticated: false }, 401);
    const today = new Date().toISOString().slice(0, 10);
    const usage = await env.DB.prepare("SELECT generation_count FROM usage_daily WHERE user_id = ? AND usage_date = ?")
      .bind(user.id, today).first();
    return json({ ok: true, authenticated: true, user: safeUser(user), usage: usage?.generation_count || 0,
      dailyLimit: user.role === "admin" || user.plan === "pro" ? PRO_DAILY_LIMIT : FREE_DAILY_LIMIT,
      developerModeAllowed: user.role === "admin" || user.plan === "pro" });
  }

  if (path === "/api/admin/setup" && method === "POST") {
    if (!env.ADMIN_SETUP_KEY) return json({ ok: false, error: "ADMIN_SETUP_KEY Secret မသတ်မှတ်ရသေးပါ။" }, 503);
    const provided = request.headers.get("X-Admin-Setup-Key") || "";
    if (provided.length !== env.ADMIN_SETUP_KEY.length || provided !== env.ADMIN_SETUP_KEY) {
      return json({ ok: false, error: "Setup key မမှန်ပါ။" }, 403);
    }
    const admins = await env.DB.prepare("SELECT COUNT(*) AS count FROM users WHERE role = 'admin'").first();
    if ((admins?.count || 0) > 0) return json({ ok: false, error: "Admin account ရှိပြီးသားဖြစ်လို့ Setup ပိတ်ထားပါတယ်။" }, 409);
    const body = await readJson(request);
    const email = normalizeEmail(body?.email);
    const password = String(body?.password || "");
    if (!validEmail(email) || !isStrongEnoughPassword(password)) {
      return json({ ok: false, error: "မှန်ကန်တဲ့ Email နဲ့ အနည်းဆုံး ၁၀ လုံး Password ထည့်ပါ။" }, 400);
    }
    const id = randomId();
    const passwordHash = await hashPassword(password);
    try {
      await env.DB.prepare("INSERT INTO users (id, email, password_hash, role, plan) VALUES (?, ?, ?, 'admin', 'pro')")
        .bind(id, email, passwordHash).run();
    } catch {
      return json({ ok: false, error: "ဒီ Email ကို အသုံးပြုပြီးသားပါ။" }, 409);
    }
    return json({ ok: true, message: "Admin ဖန်တီးပြီးပါပြီ။ ယခု Login ဝင်နိုင်ပါပြီ။" }, 201);
  }

  if (path === "/api/generate" && method === "POST") {
    const user = await requireUser(request, env);
    if (!user) return json({ ok: false, error: "Script ထုတ်ရန် Login ဝင်ပါ။", code: "AUTH_REQUIRED" }, 401);
    const body = await readJson(request);
    if (!body) return json({ ok: false, error: "Request JSON မမှန်ပါ။" }, 400);

    const isPro = user.plan === "pro" || user.role === "admin";
    if (body.developerMode && !isPro) return json({ ok: false, error: "Developer Mode သည် Pro Plan အတွက်သာ ဖြစ်ပါတယ်။", code: "PRO_REQUIRED" }, 403);
    if (!isPro) {
      const duration = String(body.duration || "60 seconds");
      const match = duration.match(/(\d+(?:\.\d+)?)\s*(minutes?|mins?|seconds?|secs?|မိနစ်|စက္ကန့်)/i);
      let seconds = 60;
      if (match) seconds = /minutes?|mins?|မိနစ်/i.test(match[2]) ? Number(match[1]) * 60 : Number(match[1]);
      if (seconds > 60) return json({ ok: false, error: "Free Plan တွင် ၆၀ စက္ကန့်အထိသာ ထုတ်နိုင်ပါတယ်။ Pro Plan သို့ အဆင့်မြှင့်ပါ။", code: "PRO_REQUIRED" }, 403);
    }

    const today = new Date().toISOString().slice(0, 10);
    const limit = isPro ? PRO_DAILY_LIMIT : FREE_DAILY_LIMIT;
    await env.DB.prepare(`INSERT INTO usage_daily (user_id, usage_date, generation_count) VALUES (?, ?, 1)
      ON CONFLICT(user_id, usage_date) DO UPDATE SET generation_count = generation_count + 1`)
      .bind(user.id, today).run();
    const usage = await env.DB.prepare("SELECT generation_count FROM usage_daily WHERE user_id = ? AND usage_date = ?")
      .bind(user.id, today).first();
    if ((usage?.generation_count || 0) > limit) {
      await env.DB.prepare("UPDATE usage_daily SET generation_count = MAX(0, generation_count - 1) WHERE user_id = ? AND usage_date = ?")
        .bind(user.id, today).run();
      return json({ ok: false, error: `ယနေ့အသုံးပြုခွင့် ${limit} ကြိမ် ပြည့်သွားပါပြီ။`, code: "DAILY_LIMIT" }, 429);
    }

    try {
      const result = await generateScript(env, body, user);
      const id = randomId();
      await env.DB.prepare("INSERT INTO scripts (id, user_id, title, topic, script) VALUES (?, ?, ?, ?, ?)")
        .bind(id, user.id, result.title, String(body.topic).trim(), result.script).run();
      return json({ ok: true, id, script: result.script, title: result.title,
        usage: usage?.generation_count || 1, dailyLimit: limit, plan: user.plan });
    } catch (error) {
      await env.DB.prepare("UPDATE usage_daily SET generation_count = MAX(0, generation_count - 1) WHERE user_id = ? AND usage_date = ?")
        .bind(user.id, today).run();
      console.error("Generation failed:", error);
      return json({ ok: false, error: error.message || "AI Script ထုတ်မရပါ။" }, 502);
    }
  }

  if (path === "/api/scripts" && method === "GET") {
    const user = await requireUser(request, env);
    if (!user) return json({ ok: false, error: "Login ဝင်ပါ။" }, 401);
    const result = await env.DB.prepare("SELECT id, title, topic, substr(script, 1, 700) AS preview, created_at FROM scripts WHERE user_id = ? ORDER BY created_at DESC LIMIT 50")
      .bind(user.id).all();
    return json({ ok: true, scripts: result.results || [] });
  }

  const scriptMatch = path.match(/^\/api\/scripts\/([a-f0-9-]+)$/i);
  if (scriptMatch && method === "GET") {
    const user = await requireUser(request, env);
    if (!user) return json({ ok: false, error: "Login ဝင်ပါ။" }, 401);
    const script = await env.DB.prepare("SELECT id, title, topic, script, created_at FROM scripts WHERE id = ? AND user_id = ?")
      .bind(scriptMatch[1], user.id).first();
    if (!script) return json({ ok: false, error: "Script မတွေ့ပါ။" }, 404);
    return json({ ok: true, script });
  }

  if (scriptMatch && method === "DELETE") {
    const user = await requireUser(request, env);
    if (!user) return json({ ok: false, error: "Login ဝင်ပါ။" }, 401);
    const result = await env.DB.prepare("DELETE FROM scripts WHERE id = ? AND user_id = ?")
      .bind(scriptMatch[1], user.id).run();
    if (!result.meta?.changes) return json({ ok: false, error: "Script မတွေ့ပါ။" }, 404);
    return json({ ok: true });
  }

  if (path === "/api/admin/users" && method === "GET") {
    const user = await requireUser(request, env);
    if (!requireAdmin(user)) return json({ ok: false, error: "Admin ခွင့်ပြုချက်လိုအပ်ပါတယ်။" }, user ? 403 : 401);
    const result = await env.DB.prepare(`SELECT id, email, role, plan, created_at,
      (SELECT COALESCE(SUM(generation_count), 0) FROM usage_daily WHERE usage_daily.user_id = users.id) AS total_generations
      FROM users ORDER BY created_at DESC LIMIT 500`).all();
    return json({ ok: true, users: result.results || [] });
  }

  const adminPlanMatch = path.match(/^\/api\/admin\/users\/([a-f0-9-]+)\/plan$/i);
  if (adminPlanMatch && method === "PATCH") {
    const admin = await requireUser(request, env);
    if (!requireAdmin(admin)) return json({ ok: false, error: "Admin ခွင့်ပြုချက်လိုအပ်ပါတယ်။" }, admin ? 403 : 401);
    const body = await readJson(request);
    if (!body || !["free", "pro"].includes(body.plan)) return json({ ok: false, error: "Plan သည် free သို့မဟုတ် pro ဖြစ်ရပါမယ်။" }, 400);
    const target = await env.DB.prepare("SELECT id, role FROM users WHERE id = ?").bind(adminPlanMatch[1]).first();
    if (!target) return json({ ok: false, error: "User မတွေ့ပါ။" }, 404);
    if (target.role === "admin" && body.plan === "free") return json({ ok: false, error: "Admin Plan ကို ဒီနေရာမှ Free မပြောင်းနိုင်ပါ။" }, 400);
    await env.DB.prepare("UPDATE users SET plan = ?, updated_at = datetime('now') WHERE id = ?")
      .bind(body.plan, target.id).run();
    return json({ ok: true, message: `User Plan ကို ${body.plan.toUpperCase()} ပြောင်းပြီးပါပြီ။` });
  }

  return json({ ok: false, error: "API route မတွေ့ပါ။" }, 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    try {
      if (url.pathname.startsWith("/api/")) return await api(request, env, url);
      if (env.ASSETS) return env.ASSETS.fetch(request);
      return json({ ok: false, error: "Assets binding မတွေ့ပါ။" }, 404);
    } catch (error) {
      console.error("Worker error:", error);
      return json({ ok: false, error: "Server အတွင်းပိုင်းအမှား ဖြစ်နေပါတယ်။" }, 500);
    }
  }
};
