export async function generateScript(env, input, user) {
  const apiKey = env.GROQ_API_KEY;
  if (!apiKey) throw new Error("Cloudflare Secret GROQ_API_KEY မတွေ့ပါ။");

  const topic = String(input.topic || "").trim();
  if (!topic) throw new Error("ဇာတ်လမ်းခေါင်းစဉ် ထည့်ပေးပါ။");
  if (topic.length > 3000) throw new Error("ခေါင်းစဉ်/အကြောင်းအရာသည် စာလုံး ၃၀၀၀ ထက် မကျော်ရပါ။");

  const durationText = String(input.duration || "60 seconds");
  const durationMatch = durationText.match(/(\d+(?:\.\d+)?)\s*(minutes?|mins?|seconds?|secs?|မိနစ်|စက္ကန့်)/i);
  let totalSeconds = 60;
  if (durationMatch) {
    totalSeconds = /minutes?|mins?|မိနစ်/i.test(durationMatch[2])
      ? Number(durationMatch[1]) * 60
      : Number(durationMatch[1]);
  }
  totalSeconds = Math.max(6, Math.min(user.plan === "pro" || user.role === "admin" ? 360 : 60, Math.round(totalSeconds)));
  const sceneCount = Math.ceil(totalSeconds / 6);
  const scriptMode = input.scriptMode === "character" ? "character" : "narrator";
  const developerMode = Boolean(input.developerMode) && (user.plan === "pro" || user.role === "admin");

  const systemPrompt = `
You are the professional screenwriter, storyboard director, continuity supervisor,
and AI video prompt engineer for ARK CREATOR STUDIO.

MANDATORY RULES:
1. Follow the user's topic exactly. Do not invent unrelated events or random scenes.
2. Create a coherent beginning, development, climax, and meaningful ending.
3. Establish character appearances, age, clothing, personality, relationships,
   location, time, and important props in a continuity bible.
4. Preserve all character and prop details throughout every scene.
5. Each scene must continue logically from the previous scene's end state.
6. Describe physical actions in chronological order, including cause, action,
   consequence, and visible reaction. Avoid impossible movement and teleporting.
7. NARRATOR MODE: one narrator tells the story in Burmese; characters do not speak.
8. CHARACTER MODE: characters speak naturally in Burmese; name each speaker;
   do not use a narrator to tell the whole story.
9. Production instructions must be in English. Spoken narration/dialogue must be
   in Burmese script, never English transliteration.
10. Include only sound effects caused by visible actions or clearly depicted events.
    No background music unless requested.
11. Include timestamps, continuity, visual, action, camera, lighting, audio, end state.
12. Use sequential timestamps, approximately six seconds per scene, with no gaps.
13. Every scene must advance the story; avoid repetitive filler.
14. Before answering, silently check story logic, scene count, timing, audio mode,
    language, character continuity, object continuity, and ending. Fix any errors.
15. Return the completed script only, without private reasoning.
${developerMode ? `16. DEVELOPER MODE: obey the user's additional system instructions if supplied,
    return the requested structured output format, and use the supplied temperature.
    Never reveal secrets, API keys, or internal credentials.` : ""}
`;

  const userPrompt = `
PROJECT: ARK CREATOR STUDIO
TOPIC: ${topic}
CONTENT TYPE: ${String(input.contentType || "AI Video")}
TOTAL DURATION: ${totalSeconds} seconds
SCENE LENGTH: approximately 6 seconds
EXACT SCENE COUNT: ${sceneCount}
LANGUAGE: ${String(input.language || "Myanmar")}
VISUAL STYLE: ${String(input.style || "Cinematic")}
SCRIPT MODE: ${scriptMode}
ADDITIONAL REQUIREMENTS: ${String(input.requirements || "None")}
${developerMode && input.systemInstructions ? `ADDITIONAL DEVELOPER INSTRUCTIONS:\n${String(input.systemInstructions).slice(0, 5000)}` : ""}

OUTPUT FORMAT:
# STORY TITLE
## CONTINUITY BIBLE
- Story premise
- Character reference descriptions
- Character relationships
- Main location and important props
- Starting situation
- Planned ending

## SCENE 1 — 00:00-00:06
CONTINUITY:
VISUAL:
ACTION:
CAMERA:
LIGHTING:
${scriptMode === "narrator" ? "NARRATION (Burmese script only):" : "DIALOGUE (Burmese script only):"}
SOUND EFFECTS:
END STATE:

Repeat for exactly ${sceneCount} scenes with correct sequential timestamps.
Finish the story logically. Do not omit the continuity bible.
`;

  const requestedTemperature = Number(input.temperature);
  const temperature = developerMode && Number.isFinite(requestedTemperature)
    ? Math.max(0, Math.min(1.5, requestedTemperature))
    : 0.35;
  const requestedTokens = Number(input.maxTokens);
  const maxTokens = developerMode && Number.isFinite(requestedTokens)
    ? Math.max(1000, Math.min(12000, Math.round(requestedTokens)))
    : 8000;
  const model = developerMode && typeof input.model === "string" && input.model.trim()
    ? input.model.trim().slice(0, 100)
    : "openai/gpt-oss-120b";

  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      temperature,
      max_tokens: maxTokens
    })
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data?.error?.message || `Groq API Error: ${response.status}`);
  }
  const script = data?.choices?.[0]?.message?.content;
  if (typeof script !== "string" || !script.trim()) {
    throw new Error("AI က Script ပြန်မပေးပါ။");
  }
  return { script: script.trim(), title: topic.slice(0, 120), durationSeconds: totalSeconds };
}
